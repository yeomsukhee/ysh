<?php
// <!-- DB Loading Start -->
$conn = new mysqli("localhost", "id11435617_azuma", "zix7211", "id11435617_azuma", "3306");
mysqli_query($conn, "set names utf8");
// <!-- DB Loading End -->
?>
